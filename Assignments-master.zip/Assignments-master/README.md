# Assignments
This repository contains some information and my assignments
<br> </br>
<b>Sam Hamers, 2014708</b>

### Assignments can be found here:
<b>Python</b>
* [Assignment 2](https://github.com/SamHamers/Assignments/blob/master/Assignment_2.ipynb)
* [Assignment 3](https://github.com/SamHamers/Assignments/blob/master/assignment_3.ipynb)
* [Assignment 4](https://github.com/SamHamers/Assignments/blob/master/assignment_4.ipynb)

<b>R</b>
* [Assignment 5](https://github.com/SamHamers/Assignments/blob/master/Assignment_5.ipynb)
* [Assignment 6](https://github.com/SamHamers/Assignments/blob/master/Assignment_6.ipynb)

### Exams
<b>Python</b>
  * [Exam Python](https://github.com/SamHamers/Assignments/blob/master/Exam_Python.ipynb)

<b>R</b>
  * [Exam R](https://github.com/SamHamers/Assignments/blob/master/Exam_R.ipynb)
 
 ### Exams September 7th
 <b>Python</b>
  * [Exam Python September 7, 2018](https://github.com/SamHamers/Assignments/blob/master/Exam_Python_September_7_2018.ipynb)
 
 <b>R</b>
  * [Exam R September 7, 2018](https://github.com/SamHamers/Assignments/blob/master/Exam_R_September_7_2018.ipynb)
